export interface Device {
  name: string;
  currentVersion: string;
  availableVersion: string;
  status: string;
  lastUpdated: string;
  icon: string;
}

export interface Organization {
  id: string;
  name: string;
  devices: Device[];
}