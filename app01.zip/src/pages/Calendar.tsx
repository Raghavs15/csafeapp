import React from 'react';
import { Calendar as CalendarIcon } from 'lucide-react';

const Calendar = () =>
{
  return (
    <div className="min-h-screen bg-primary-dark pt-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-primary/30 rounded-lg p-8">
          <div className="flex items-center gap-4 mb-8">
            <CalendarIcon className="h-8 w-8 text-primary-light" />
            <h1 className="text-3xl font-bold text-white">Update Calendar</h1>
          </div>
          <div className="grid gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-primary-dark/50 p-6 rounded-lg border border-primary-light/20">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-white font-semibold mb-2">Scheduled Update {i + 1}</h3>
                    <p className="text-gray-400">Maintenance Window: March {15 + i}, 2024</p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-primary-light/20 text-primary-light text-sm">
                    Upcoming
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Calendar;