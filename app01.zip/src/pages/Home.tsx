import React from 'react';
import Hero from '../components/sections/Hero';
import Dashboard from '../components/dashboard/Dashboard';

const Home = () => {
  return (
    <>
      <Hero />
      <div id="dashboard">
        <Dashboard />
      </div>
    </>
  );
};

export default Home;