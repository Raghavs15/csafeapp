import React from 'react';
import { HelpCircle } from 'lucide-react';

const FAQ = () => {
  const faqs = [
    {
      question: "How often should I update my devices?",
      answer: "We recommend updating your devices as soon as new security patches become available. For feature updates, we suggest reviewing the changelog before proceeding."
    },
    {
      question: "What happens during a rollback?",
      answer: "During a rollback, your device will revert to the previous stable version. All settings and data will be preserved, but any features from the newer version will be temporarily unavailable."
    },
    {
      question: "How are update statuses determined?",
      answer: "Update statuses are calculated based on version differences. Critical updates are those more than 10 versions behind, while available updates are within 10 versions."
    }
  ];

  return (
    <div className="min-h-screen bg-primary-dark pt-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-primary/30 rounded-lg p-8">
          <div className="flex items-center gap-4 mb-8">
            <HelpCircle className="h-8 w-8 text-primary-light" />
            <h1 className="text-3xl font-bold text-white">Frequently Asked Questions</h1>
          </div>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-primary-dark/50 p-6 rounded-lg border border-primary-light/20">
                <h3 className="text-white font-semibold mb-2">{faq.question}</h3>
                <p className="text-gray-400">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQ;