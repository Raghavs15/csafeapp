export function parseVersion(version: string): number[] {
  return version
    .replace('v', '')
    .split('.')
    .map(Number);
}

export function calculateVersionDifference(current: string, available: string): number {
  const currentParts = parseVersion(current);
  const availableParts = parseVersion(available);
  
  const majorDiff = availableParts[0] - currentParts[0];
  const minorDiff = availableParts[1] - currentParts[1];
  const patchDiff = availableParts[2] - currentParts[2];
  
  return majorDiff * 10 + minorDiff + (patchDiff > 0 ? 0.1 : 0);
}