import { Device } from '../types/device';

export const devices: Device[] = [
  { name: 'Data Shield Y80', currentVersion: 'v2.2.7', availableVersion: 'v2.2.7', status: 'Up to Date', lastUpdated: '2024-06-07', icon: '🛡️' },
  { name: 'Smart Monitor N29', currentVersion: 'v3.1.8', availableVersion: 'v3.10.8', status: 'Up to Date', lastUpdated: '2023-11-04', icon: '🖥️' },
  { name: 'Data Shield Y74', currentVersion: 'v3.3.5', availableVersion: 'v3.3.5', status: 'Up to Date', lastUpdated: '2024-10-27', icon: '🛡️' },
  { name: 'Data Shield U10', currentVersion: 'v2.2.3', availableVersion: 'v2.10.3', status: 'Up to Date', lastUpdated: '2023-03-28', icon: '🛡️' },
  { name: 'Data Shield Y80', currentVersion: 'v2.2.7', availableVersion: 'v2.3.7', status: 'Update Available', lastUpdated: '2024-06-07', icon: '🛡️' },
  { name: 'Smart Monitor N29', currentVersion: 'v3.1.8', availableVersion: 'v3.10.8', status: 'Update Available', lastUpdated: '2023-11-04', icon: '🖥️' },
  { name: 'Data Shield Y74', currentVersion: 'v3.3.5', availableVersion: 'v3.4.5', status: 'Update Available', lastUpdated: '2024-10-27', icon: '🛡️' },
  { name: 'Data Shield U10', currentVersion: 'v2.2.3', availableVersion: 'v2.10.3', status: 'Update Available', lastUpdated: '2023-03-28', icon: '🛡️' },
  { name: 'Data Shield Y80', currentVersion: 'v2.2.7', availableVersion: 'v2.2.7', status: 'Updating', lastUpdated: '2024-06-07', icon: '🛡️' },
  { name: 'Smart Monitor N29', currentVersion: 'v3.1.8', availableVersion: 'v3.10.8', status: 'Updating', lastUpdated: '2023-11-04', icon: '🖥️' },
  { name: 'Data Shield Y74', currentVersion: 'v3.3.5', availableVersion: 'v3.3.5', status: 'Updating', lastUpdated: '2024-10-27', icon: '🛡️' },
  { name: 'Data Shield U10', currentVersion: 'v2.2.3', availableVersion: 'v2.10.3', status: 'Updating', lastUpdated: '2023-03-28', icon: '🛡️' },
];
