import { Organization } from '../types/device';
 
const devices = [
  { name: 'Security Gate D30', currentVersion: 'v1.1.8', availableVersion: 'v1.1.8', status: 'Up to Date', lastUpdated: '2023-05-09', icon: '🔒' },
  { name: 'Network Scanner O32', currentVersion: 'v3.0.1', availableVersion: 'v3.0.1', status: 'Up to Date', lastUpdated: '2023-09-02', icon: '📡' },
  { name: 'Data Shield E53', currentVersion: 'v2.4.4', availableVersion: 'v2.14.4', status: 'Up to Date', lastUpdated: '2024-10-06', icon: '🛡️' },
  { name: 'Smart Monitor G57', currentVersion: 'v9.7.8', availableVersion: 'v12.0.0', status: 'Critical Update', lastUpdated: '2023-11-22', icon: '🖥️' },
  { name: 'Data Shield D97', currentVersion: 'v4.9.7', availableVersion: 'v4.19.7', status: 'Up to Date', lastUpdated: '2023-06-06', icon: '🛡️' },
  { name: 'Security Gate N43', currentVersion: 'v13.3.1', availableVersion: 'v13.10.0', status: 'Critical Update', lastUpdated: '2023-03-05', icon: '🔒' },
  { name: 'Access Control U34', currentVersion: 'v0.4.7', availableVersion: 'v0.4.7', status: 'Up to Date', lastUpdated: '2023-05-29', icon: '🔑' },
  { name: 'Access Control X78', currentVersion: 'v11.5.0', availableVersion: 'v16.0.0', status: 'Critical Update', lastUpdated: '2024-05-21', icon: '🔑' },
  { name: 'Data Shield Y80', currentVersion: 'v2.2.7', availableVersion: 'v2.2.7', status: 'Up to Date', lastUpdated: '2024-06-07', icon: '🛡️' },
  { name: 'Smart Monitor N29', currentVersion: 'v3.1.8', availableVersion: 'v3.10.8', status: 'Up to Date', lastUpdated: '2023-11-04', icon: '🖥️' },
  { name: 'Data Shield Y74', currentVersion: 'v3.3.5', availableVersion: 'v3.3.5', status: 'Up to Date', lastUpdated: '2024-10-27', icon: '🛡️' },
  { name: 'Data Shield U10', currentVersion: 'v2.2.3', availableVersion: 'v2.10.3', status: 'Up to Date', lastUpdated: '2023-03-28', icon: '🛡️' }
];

export const organizations: Organization[] = [
  {
    id: 'techcorp',
    name: 'TechCorp Industries',
    devices: devices
  },
  {
    id: 'smartdevice',
    name: 'SmartDevice Solutions',
    devices: devices
  },
  {
    id: 'powertech',
    name: 'PowerTech Systems',
    devices: devices
  },
  {
    id: 'innovatex',
    name: 'InnovateX Electronics',
    devices: devices
  },
  {
    id: 'globaltech',
    name: 'GlobalTech Enterprises',
    devices: devices
  },
  {
    id: 'devicepro',
    name: 'DevicePro International',
    devices: devices
  }
];
