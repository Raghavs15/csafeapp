import React from 'react';
import { Shield } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-primary-dark border-t border-primary-light/10">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-center mb-4">
          <Shield className="h-6 w-6 text-primary-light" />
          <span className="ml-2 text-white font-bold text-lg">CyberSafe</span>
        </div>
        <p className="text-center text-gray-400 text-sm">
          © {new Date().getFullYear()} CyberSafe. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;