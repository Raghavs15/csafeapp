import { motion } from 'framer-motion';
import { Device } from '../../types/device';
import { calculateVersionDifference } from '../../utils/version';
import { DeviceDialog } from './DeviceDialog';
import { useState } from 'react';

interface DeviceCardProps {
  device: Device;
  onUpdate: (deviceName: string, newVersion: string) => void;
}

const DeviceCard = ({ device, onUpdate }: DeviceCardProps) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const versionDiff = calculateVersionDifference(device.currentVersion, device.availableVersion);
  
  const getBorderColor = () => {
    if (versionDiff > 10) return 'from-red-500/50 to-red-600/50';
    if (versionDiff > 0) return 'from-yellow-500/50 to-yellow-600/50';
    return 'from-green-500/50 to-green-600/50';
  };

  const getStatusColor = () => {
    if (versionDiff > 10) return 'text-red-400';
    if (versionDiff > 0) return 'text-yellow-400';
    return 'text-green-400';
  };

  const getStatusText = () => {
    if (versionDiff > 10) return 'Critical Update';
    if (versionDiff > 0) return 'Update Available';
    return 'Up to Date';
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`relative p-6 rounded-lg bg-primary-dark/30 backdrop-blur-sm cursor-pointer
          hover:bg-primary-dark/40 transition-colors
          before:absolute before:inset-0 before:-z-10 before:rounded-lg
          before:bg-gradient-to-r ${getBorderColor()} before:p-[1px]`}
        onClick={() => setIsDialogOpen(true)}
      >
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
              <h3 className="text-lg font-semibold text-white mb-1">{device.name}</h3>
            <span className="text-2xl">{device.icon}</span>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Current Version</span>
            <span className="text-white">{device.currentVersion}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Available Version</span>
            <span className="text-white">{device.availableVersion}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Last Updated</span>
            <span className="text-white">{device.lastUpdated}</span>
          </div>
        </div>
        <hr className='border-white border-t mt-4'/>
        <p className={`text-sm pt-4 font-medium ${getStatusColor()}`}>{getStatusText()}</p>
      </motion.div>

      <DeviceDialog 
        device={device}
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        onUpdate={onUpdate}
      />
    </>
  );
};

export default DeviceCard;