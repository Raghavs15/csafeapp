import { useState } from 'react';
import { motion } from 'framer-motion';
import { Select } from '../ui/Select';
import DeviceCard from './DeviceCard';
import { organizations } from '../../data/organizations';
import { calculateVersionDifference } from '../../utils/version';
import type { Device } from '../../types/device';

const Dashboard = () => {
  const [selectedOrg, setSelectedOrg] = useState(organizations[0].id);
  const [statusFilter, setStatusFilter] = useState('all');

  const currentOrg = organizations.find(org => org.id === selectedOrg)!;

  const filterDevices = (devices: Device[]) => {
    return devices.filter(device => {
      const diff = calculateVersionDifference(device.currentVersion, device.availableVersion);
      switch (statusFilter) {
        case 'critical':
          return diff > 10;
        case 'available':
          return diff > 0 && diff <= 10;
        case 'uptodate':
          return diff === 0;
        default:
          return true;
      }
    });
  };

  return (
    <div className="min-h-screen bg-primary-dark p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-6">Device Monitoring Dashboard</h1>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select
              label="Organization"
              value={selectedOrg}
              onChange={(e) => setSelectedOrg(e.target.value)}
            >
              {organizations.map(org => (
                <option key={org.id} value={org.id}>{org.name}</option>
              ))}
            </Select>

            <Select
              label="Status Filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All Devices</option>
              <option value="critical">Critical Updates</option>
              <option value="available">Updates Available</option>
              <option value="uptodate">Up to Date</option>
            </Select>
          </div>
        </div>

        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filterDevices(currentOrg.devices).map((device) => (
            <DeviceCard key={device.name} device={device}  />
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;