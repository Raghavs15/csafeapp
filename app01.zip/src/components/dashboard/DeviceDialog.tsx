import React, { useState } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Device } from '../../types/device';
import { Button } from '../ui/Button';
import { UpdateProgress } from './UpdateProgress';
import { DeviceAnalytics } from './DeviceAnalytics';

interface DeviceDialogProps {
  device: Device;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (deviceName: string, newVersion: string) => void;
}

export const DeviceDialog = ({ device, isOpen, onClose, onUpdate }: DeviceDialogProps) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);

  const handleUpdate = async () => {
    setIsUpdating(true);
    await new Promise(resolve => setTimeout(resolve, 5000)); // Simulate update process
    onUpdate(device.name, device.availableVersion);
    setIsUpdating(false);
    onClose();
  };

  return (
    <Dialog.Root open={isOpen} onOpenChange={onClose}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50 backdrop-blur-sm" />
        <Dialog.Content className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg bg-primary-dark p-6 rounded-lg shadow-xl">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{device.icon}</span>
              <div>
                <Dialog.Title className="text-xl font-semibold text-white">
                  {device.name}
                </Dialog.Title>
                <p className="text-gray-400">Device Details</p>
              </div>
            </div>
            <Dialog.Close asChild>
              <button className="text-gray-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </Dialog.Close>
          </div>

          <AnimatePresence mode="wait">
            {isUpdating ? (
              <UpdateProgress />
            ) : showAnalytics ? (
              <DeviceAnalytics onBack={() => setShowAnalytics(false)} />
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="space-y-4 mb-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-primary/30 p-4 rounded-lg">
                      <p className="text-gray-400 text-sm mb-1">Current Version</p>
                      <p className="text-white font-medium">{device.currentVersion}</p>
                    </div>
                    <div className="bg-primary/30 p-4 rounded-lg">
                      <p className="text-gray-400 text-sm mb-1">Available Version</p>
                      <p className="text-white font-medium">{device.availableVersion}</p>
                    </div>
                  </div>
                  <div className="bg-primary/30 p-4 rounded-lg">
                    <p className="text-gray-400 text-sm mb-1">Last Updated</p>
                    <p className="text-white font-medium">{device.lastUpdated}</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  {device.currentVersion !== device.availableVersion && (
                    <Button className="flex-1" onClick={handleUpdate}>
                      Sync with Latest
                    </Button>
                  )}
                  <Button   className="flex-1" onClick={() => setShowAnalytics(true)}>
                    View Analytics
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
};