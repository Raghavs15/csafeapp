import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from 'recharts';

interface DeviceAnalyticsProps {
  onBack: () => void;
}

export const DeviceAnalytics = ({ onBack }: DeviceAnalyticsProps) => {
  const updateData = [
    { name: 'Jan', updates: 4 },
    { name: 'Feb', updates: 3 },
    { name: 'Mar', updates: 6 },
  ];

  const issueData = [
    { name: 'Patches', value: 45 },
    { name: 'Errors', value: 25 },
    { name: 'Faults', value: 30 },
  ];

  const COLORS = ['#8B6BFF', '#FF6B6B', '#4CAF50'];

  return (
    <div className="space-y-6">
      <div className="space-y-6">
        <div>
          <h3 className="text-white font-medium mb-4">Update History</h3>
          <div className="bg-primary/30 p-4 rounded-lg">
            <BarChart width={400} height={200} data={updateData}>
              <XAxis dataKey="name" stroke="#8B6BFF" />
              <YAxis stroke="#8B6BFF" />
              <Tooltip />
              <Bar dataKey="updates" fill="#8B6BFF" />
            </BarChart>
          </div>
        </div>

        <div>
          <h3 className="text-white font-medium mb-4">Overall Stats</h3>
          <div className="bg-primary/30 p-4 rounded-lg">
            <PieChart width={400} height={200}>
              <Pie
                data={issueData}
                cx={200}
                cy={100}
                innerRadius={60}
                outerRadius={80}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
              >
                {issueData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </div>
        </div>
        <Button className="flex-1" onClick={onBack}>
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back
      </Button>
      </div>
    </div>
  );
};