import React, { useEffect, useState } from 'react';
import * as Progress from '@radix-ui/react-progress';
import { motion } from 'framer-motion';

const steps = [
  { label: 'Getting files', duration: 1000 },
  { label: 'Applying update', duration: 1500 },
  { label: 'Finalizing', duration: 1000 },
  { label: 'Checking', duration: 800 },
  { label: 'Done', duration: 700 },
];

export const UpdateProgress = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const runSteps = async () => {
      for (let i = 0; i < steps.length; i++) {
        setCurrentStep(i);
        const increment = 100 / steps.length;
        const startProgress = (i / steps.length) * 100;
        
        await new Promise<void>((resolve) => {
          let start = 0;
          const interval = setInterval(() => {
            start += 2;
            setProgress(Math.min(startProgress + (start * increment) / 100, (i + 1) * increment));
            if (start >= 100) {
              clearInterval(interval);
              resolve();
            }
          }, steps[i].duration / 50);
        });
      }
    };

    runSteps();
  }, []);

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-primary-light">{steps[currentStep].label}</span>
          <span className="text-gray-400">{Math.round(progress)}%</span>
        </div>
        <Progress.Root className="relative overflow-hidden bg-primary/30 rounded-full w-full h-2">
          <Progress.Indicator
            className="bg-primary-light w-full h-full transition-transform duration-300 ease-out"
            style={{ transform: `translateX(-${100 - progress}%)` }}
          />
        </Progress.Root>
      </div>

      <div className="grid grid-cols-5 gap-2">
        {steps.map((step, index) => (
          <motion.div
            key={step.label}
            className={`h-1 rounded-full ${
              index <= currentStep ? 'bg-primary-light' : 'bg-primary/30'
            }`}
            initial={{ scaleX: 0 }}
            animate={{ scaleX: index <= currentStep ? 1 : 0 }}
            transition={{ duration: 0.3 }}
          />
        ))}
      </div>
    </div>
  );
};