import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate, useNavigate } from 'react-router-dom';
import CybersecurityInfo from './components/CybersecurityInfo/CybersecurityInfo';
import FirmwareVersions from './components/FirmwareVersions/FirmwareVersions';
import SafetyMeasures from './components/SafetyMeasures/SafetyMeasures';
import { useLocation } from 'react-router-dom';
import Footer from './components/shared/Footer/Footer';
 
export default function App()
{
  return (
    <Router>
      <Main />
    </Router>
  );
}

const Main = () =>
{
  const location = useLocation();

  const texts = [' . . .'];
  const [text, setText] = useState('');
  const [index, setIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() =>
  {
    const handleTyping = () =>
    {
      const currentText = texts[index];

      if (!isDeleting)
      {
        setText(currentText.slice(0, charIndex + 1));
        setCharIndex((prev) => prev + 1);

        if (charIndex === currentText.length)
        {
          setTimeout(() => setIsDeleting(true), 1500);
        }
      } else
      {
        setText(currentText.slice(0, charIndex - 1));
        setCharIndex((prev) => prev - 1);

        if (charIndex === 0)
        {
          setIsDeleting(false);
          setIndex((prev) => (prev + 1) % texts.length);
        }
      }
    };

    const typingSpeed = isDeleting ? 70 : 120;
    const timer = setTimeout(handleTyping, typingSpeed);

    return () => clearTimeout(timer);
  }, [charIndex, isDeleting, index, texts]);

  const ProtectedRoute = ({ element: Component, ...rest }) =>
  {
    return <Component {...rest} />;
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <header className="flex justify-between items-center p-4">
        <h1 className="text-4xl typewriter">Cybersafe Devices{text}</h1>
        <nav className="flex justify-end space-x-4">
        <Link to="/" className={`text-lg ${location.pathname === '/' ? 'active-menu' : ''}`}>Home</Link>
              <Link to="/firmware" className={`text-lg ${location.pathname === '/firmware' ? 'active-menu' : ''}`}>Firmware Versions</Link>
              <Link to="/safety" className={`text-lg ${location.pathname === '/safety' ? 'active-menu' : ''}`}>Safety Measures</Link>
        </nav>
      </header>

      <Routes>
        <Route path="/" element={<ProtectedRoute element={CybersecurityInfo} />} />
        <Route path="/firmware" element={<ProtectedRoute element={FirmwareVersions} />} />
        <Route path="/safety" element={<ProtectedRoute element={SafetyMeasures} />} />
      </Routes>
      <Footer />
    </div>
  );
};

