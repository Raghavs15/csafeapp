import React from 'react';
import { render } from '@testing-library/react';
import DeviceChart from './DeviceChart';

const mockDevice = {
  name: 'Power Logic T300',
};

test('renders DeviceChart component', () => {
    render(<DeviceChart device={mockDevice} />);
    // Add more specific tests as needed
});
