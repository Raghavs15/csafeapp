import React, { useState, useEffect } from 'react';
import './Modal.css';
import DeviceChart from '../../DeviceChart/DeviceChart';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

const Modal = ({ isOpen, onClose, content, chartData }) =>
{
  const [isFlipped, setIsFlipped] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [syncStatus, setSyncStatus] = useState('');

  if (!isOpen) return null;

  const handleFlip = () =>
  {
    setIsFlipped(true);
  };

  const handleFlipBack = () =>
  {
    setIsFlipped(false);
  };

  const handleSync = () =>
  {
    setIsSyncing(true);
    setSyncProgress(0);
    setSyncStatus('Connecting to server');

    const interval = setInterval(() =>
    {
      setSyncProgress((prevProgress) =>
      {
        if (prevProgress >= 100)
        {
          clearInterval(interval);
          setIsSyncing(false);
          setSyncStatus('');
          return 100;
        }
        if (prevProgress < 25)
        {
          setSyncStatus('Updating...');
        } else if (prevProgress < 50)
        {
          setSyncStatus('Collecting files...');
        } else if (prevProgress < 75)
        {
          setSyncStatus('Finalizing');
        } else
        {
          setSyncStatus('Completed');
        }

        return prevProgress + 5;
      });
    }, 500);

    // Simulate sync logic
    console.log('Syncing with the latest build...');
  };

  const handleRollback = () =>
  {
    console.log('Rolling back to the previous version...');
    // Add your rollback logic here
  };

  const handleCheckLogs = () =>
  {
    console.log('Checking logs...');
    // Add your log checking logic here
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h2 className="modal-title">
            {content.name} {content.icon}
            <button className="action-button" onClick={handleSync}>Sync</button>

          </h2>
          <button onClick={onClose}>
            ❌
          </button>
        </div>
        <hr />
        <div>
          {isSyncing && (
            <div className="progress-container">
              <CircularProgressbar
                value={syncProgress}
                text={`${syncStatus + syncProgress}%`}
                background
                backgroundPadding={6}
                styles={buildStyles({
                  backgroundColor: "#3e98c7",
                  pathColor: `hsl(${(syncProgress * 120) / 100}, 100%, 50%)`,
                  textColor: "#fff",
                  pathColor: "#fff",
                  trailColor: "transparent",
                  // Customize the text
                  text: {
                    // Text color
                    fill: '#f88',
                    // Text size
                    fontSize: '5px',
                  },
                  // Customize background - only used when the `background` prop is true
                  background: {
                    fill: '#3e98c7',
                  },
                })}
              />
            </div>
          )}
          <div className={`flip-container ${isFlipped ? 'flipped' : ''}`}>
            <div className="flipper">
              <div className="modal-body front">
                <div className="modal-details">
                  <p><strong>Current Version:</strong> {content.currentVersion}</p>
                  <p><strong>Available Version:</strong> {content.availableVersion}</p>
                  <p><strong>Status:</strong> {content.status || "N/A"}</p>
                  <p><strong>Last Updated:</strong> {content.lastUpdated}</p>
                </div>
                <div className="modal-actions">
                  <button className="action-button" onClick={handleRollback}>Rollback</button>
                  <button className="action-button" onClick={handleCheckLogs}>Logs</button>
                  <button className="action-button" onClick={handleFlip}>View Chart</button>
                </div>
              </div>
              <div className="modal-details back">
                <DeviceChart device={content} chartData={chartData} />
                <button className="action-button" onClick={handleFlipBack}>Back</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;