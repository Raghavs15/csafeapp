import React, { useState } from 'react';
 
import PropTypes from 'prop-types';

const Calendar = ({ year, monthName, dummyData }) => 
{
    const currentMonth = new Date(year, new Date().getMonth());
    const daysInMonth = new Date(year, currentMonth.getMonth() + 1, 0).getDate();
    const firstDay = new Date(year, currentMonth.getMonth(), 1).getDay();
  
    // Create an array of dates for the current month
    const dates = Array.from({ length: daysInMonth }, (_, index) => index + 1);
  
    // Extract dates from dummyData for highlighting
    const highlightedDates = new Set(dummyData.map(data => new Date(data.date).getDate()));
  
    return (
      <div className="calendar grid grid-cols-7 gap-4 mt-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="font-bold">{day}</div>
        ))}
        {/* Empty cells for days before the first day of the month */}
        {Array.from({ length: firstDay }).map((_, index) => (
          <div key={index} className="opacity-0">.</div>
        ))}
        {dates.map(date => (
          <div key={date} className={`p-2 border-dashed text-center ${highlightedDates.has(date) ? 'bg-blue-500 text-white text-bold' : 'bg-black-200'}`}>
            {date}
          </div>
        ))}
      </div>
    );
  };

export default Calendar;