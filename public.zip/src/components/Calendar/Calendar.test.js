import React from 'react';
import { render } from '@testing-library/react';
import Calendar from './Calendar';

const mockData = [ 
  { date: '2024-01-15' },
  { date: '2024-02-20' },
  // Add more mock data as needed
];

test('renders Calendar component', () => {
    render(<Calendar year={2024} monthName="January" dummyData={mockData} />);
    // Add more specific tests as needed
});
