import React from 'react';
import { render } from '@testing-library/react';
import SafetyMeasures from './SafetyMeasures';

test('renders SafetyMeasures component', () => {
  render(<SafetyMeasures />);
  // Add more specific tests as needed
});
