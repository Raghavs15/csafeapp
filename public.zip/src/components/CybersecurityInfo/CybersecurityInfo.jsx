import React, { useState } from 'react';
import Modal from '../shared/Modal/Modal';
import { initialDevices } from './data';

const getStatusClass = (status) =>
{
  switch (status)
  {
    case 'Up to date':
      return 'bg-green-500';
    case 'Update Available':
      return 'bg-yellow-500';
    case 'Critial':
      return 'bg-red-500';
    default:
      return '';
  }
};

const CybersecurityInfo = () =>
{
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [filter, setFilter] = useState('all'); // State for filter
  const [devices, setDevices] = useState(initialDevices); // State for devices
  const [openModel, setOpenModal] = useState(false);

  const handleDeviceClick = (device) =>
  {
    setOpenModal(true);
    setSelectedDevice(device);
  };

  // Filter devices based on selected filter
  const filteredDevices = devices.filter(device =>
  {
    const versionDifference = parseFloat(device.availableVersion.split('v')[1]) - parseFloat(device.currentVersion.split('v')[1]);
    if (filter === 'red') return versionDifference > 10;
    if (filter === 'green') return versionDifference === 0;
    if (filter === 'yellow') return versionDifference <= 10 && versionDifference != 0;
    return true;
  });

  const syncData = () =>
  {
    const newDevices = devices.map(device => ({
      ...device,
      currentVersion: `v${(Math.random() * 10).toFixed(1)}`, // Random current version
      availableVersion: `v${(Math.random() * 15).toFixed(1)}`, // Random available version
      lastUpdated: new Date().toISOString().split('T')[0], // Update last updated date
    }));
    setDevices(newDevices);
  };

  return (
    <div className="p-4 bg-gray-800 text-white rounded-lg">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Version Information</h2>
        <div className="mt-4">
          <label className="mr-2">Filter by Status:</label>
          <select value={filter} onChange={(e) => setFilter(e.target.value)} className="bg-gray-700 text-white rounded p-2">
            <option value="all">All</option>
            <option value="red">Critical</option>
            <option value="yellow">Available</option>
            <option value="green">No Updates</option>
          </select>
        </div>
        <button
          onClick={syncData}
          className="rounded border-zinc-200 rounded-full"
        >
          <span className="material-icons mr-2"></span> Sync Data
        </button>
      </div>
      <p>Firmware update information on {filteredDevices.length} devices.</p>

      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredDevices.map((device) =>
        {
          const versionDifference = parseFloat(device.availableVersion.split('v')[1]) - parseFloat(device.currentVersion.split('v')[1]);
          let status = '';
          if (versionDifference > 10)
          {
            status = 'Critial';
          } else if (versionDifference === 0)
          {
            status = 'Up to date';
          } else if (versionDifference <= 10)
          {
            status = 'Update Available';
          }

          return (
            <div
              key={device.name}
              className={`p-4 rounded-lg  ${getStatusClass(status)}`}
              onClick={() =>
              {
                console.log('Click event triggered for:', device.name); // Log the click event
                handleDeviceClick(device);
              }}
            >
              <h3 className="text-xl font-semibold">{device.icon} {device.name}</h3>
              <p>Current Version: {device.currentVersion}</p>
              <p>Available Version: {device.availableVersion}</p>
              <p>Status: {status}</p>
              <p>Last Updated: {device.lastUpdated}</p>
            </div>
          );

        })}


      </div>

      {selectedDevice && <Modal isOpen={openModel} onClose={() => setOpenModal(false)} content={selectedDevice} chartData={selectedDevice} />}

    </div>
  );
};

export default CybersecurityInfo;
