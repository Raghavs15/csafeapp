import React from 'react';
import { render } from '@testing-library/react';
import CybersecurityInfo from './CybersecurityInfo';

const initialDevices = [
  { name: 'Power Logic T300', currentVersion: 'v2.5.6', availableVersion: 'v2.7.5', status: '', lastUpdated: '2023-09-01', icon: '🔌' },
  // Add more initial devices as needed
];

test('renders CybersecurityInfo component', () => {
  render(<CybersecurityInfo devices={initialDevices} />);
  // Add more specific tests as needed
});
