
export const initialDevices = [
    { name: 'Power Logic T300', currentVersion: 'v2.5.6', availableVersion: 'v2.7.5', status: '', lastUpdated: '2023-09-01', icon: '🔌' },
    { name: 'Device A1', currentVersion: 'v1.0.0', availableVersion: 'v1.0.0', status: '', lastUpdated: '2023-08-15', icon: '🛠️' },
    { name: 'Device A2', currentVersion: 'v1.2.3', availableVersion: 'v1.2.3', status: '', lastUpdated: '2023-08-20', icon: '📡' },
    { name: 'Device A3', currentVersion: 'v1.1.0', availableVersion: 'v11.2.0', status: '', lastUpdated: '2023-07-20', icon: '📡' },
    { name: 'Device A8', currentVersion: 'v1.1.0', availableVersion: 'v12.1.0', status: '', lastUpdated: '2023-09-15', icon: '✅' },
    { name: 'Device A9', currentVersion: 'v1.3.0', availableVersion: 'v1.4.0', status: '', lastUpdated: '2023-09-01', icon: '🔌' },
    { name: 'Device B1', currentVersion: 'v2.0.0', availableVersion: 'v12.2.0', status: '', lastUpdated: '2023-09-01', icon: '🔌' },
    { name: 'Device B2', currentVersion: 'v1.0.0', availableVersion: 'v1.0.5', status: '', lastUpdated: '2023-08-15', icon: '🛠️' },
    { name: 'Device B3', currentVersion: 'v1.2.3', availableVersion: 'v1.2.3', status: '', lastUpdated: '2023-08-20', icon: '📡' },
    { name: 'Device B7', currentVersion: 'v1.0.0', availableVersion: 'v1.0.1', status: '', lastUpdated: '2023-09-05', icon: '⚙️' },
    { name: 'Device B8', currentVersion: 'v1.5.0', availableVersion: 'v1.6.0', status: '', lastUpdated: '2023-08-20', icon: '❌' },
    { name: 'Device B9', currentVersion: 'v2.1.0', availableVersion: 'v15.1.0', status: '', lastUpdated: '2023-09-15', icon: '✅' },
  ];
  