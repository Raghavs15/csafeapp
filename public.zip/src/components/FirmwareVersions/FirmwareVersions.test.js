import React from 'react';
import { render } from '@testing-library/react';
import FirmwareVersions from './FirmwareVersions';

const mockData = [
  { date: '2024-01-15', version: 'v1.0.0', synced: 10, pending: 2 },
  { date: '2024-02-20', version: 'v1.1.0', synced: 15, pending: 1 },
  // Add more mock data as needed
];

test('renders FirmwareVersions component', () => {
  render(<FirmwareVersions initialData={mockData} />);
  // Add more specific tests as needed
});
