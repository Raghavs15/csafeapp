import React, { useState } from 'react';
import Calendar from '../Calendar/Calendar';

const initialData = [
  { date: '2024-01-15', version: 'v1.0.0', synced: 10, pending: 2 },
  { date: '2024-02-20', version: 'v1.1.0', synced: 15, pending: 1 },
  { date: '2024-03-10', version: 'v1.2.0', synced: 20, pending: 0 },
  { date: '2024-04-05', version: 'v1.3.0', synced: 5, pending: 5 },
  { date: '2024-05-18', version: 'v1.4.0', synced: 8, pending: 3 },
  { date: '2024-06-22', version: 'v1.5.0', synced: 12, pending: 0 },
  { date: '2024-07-30', version: 'v1.6.0', synced: 18, pending: 2 },
  { date: '2024-08-14', version: 'v1.7.0', synced: 25, pending: 1 },
  { date: '2024-09-01', version: 'v1.8.0', synced: 30, pending: 0 },
  { date: '2024-10-10', version: 'v1.9.0', synced: 22, pending: 3 },
  { date: '2024-11-15', version: 'v2.0.0', synced: 10, pending: 5 },
  { date: '2024-12-20', version: 'v2.1.0', synced: 15, pending: 2 },
  { date: '2024-11-27', version: 'v2.1.0', synced: 15, pending: 2 },
];

const FirmwareVersions = ({ date }) =>
{
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [dummyData, setDummyData] = useState(initialData);

  const handlePrevMonth = () =>
  {
    setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() - 1)));
  };

  const handleNextMonth = () =>
  {
    setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() + 1)));
  };

  const syncData = () =>
  {
    const newData = dummyData.map(data => ({
      ...data,
      version: `v${(Math.random() * 10).toFixed(1)}`, // Random version
      synced: Math.floor(Math.random() * 30), // Random synced count
      pending: Math.floor(Math.random() * 10), // Random pending count
    }));
    setDummyData(newData);
  };

  const monthName = currentMonth.toLocaleString('default', { month: 'long' });
  const year = currentMonth.getFullYear();

  return (
    <div className="p-4 bg-gray-800 text-white rounded-lg">

      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Firmware Versions</h2>
        <p>Information about the latest firmware versions and updates.</p>
        <button onClick={syncData} className="bg-blue-500 p-2 rounded mt-4"> Refresh </button>
      </div>



      <div className="flex justify-between items-center mt-4">
        <button onClick={handlePrevMonth} className="bg-gray-700 p-2 rounded">←</button>
        <h3 className="font-semibold">{`${monthName} ${year}`}</h3>
        <button onClick={handleNextMonth} className="bg-gray-700 p-2 rounded">→</button>
      </div>
      <div className="flex">
        <div className="w-1/2">
          <Calendar year={year} monthName={monthName} dummyData={dummyData.filter(data => new Date(data.date).getMonth() === currentMonth.getMonth() && new Date(data.date).getFullYear() === year)} />
        </div>
        <div className="w-1/2 mt-4">
          {dummyData.filter(data => new Date(data.date).getMonth() === currentMonth.getMonth() && new Date(data.date).getFullYear() === year).map((data, index) => (
            <div key={index} className="border-b border-gray-600 py-2">
              <h4 className="font-semibold">{`Version: ${data.version}`}</h4>
              <p>{`Devices Synced: ${data.synced}`}</p>
              <p>{`Devices Pending: ${data.pending}`}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FirmwareVersions;
