export const DUMMY_USER = {
  username: 'AppAdmin',
  password: 'Admin@123',
};
