import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import CybersecurityInfo from './CybersecurityInfo';
import FirmwareVersions from './FirmwareVersions';
import SafetyMeasures from './SafetyMeasures';
import { useLocation } from 'react-router-dom'; // Import useLocation

const App = () =>
{
  return (
    <Router>
      <Main />
    </Router>
  );
};

const Main = () =>
{
  const location = useLocation(); // Get current location

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <header className="flex justify-between items-center p-4">
        <h1 className="text-4xl">Cybersafe Devices</h1>
        <nav className="flex justify-end space-x-4">
          <Link to="/" className={`text-lg ${location.pathname === '/' ? 'active-menu' : ''}`}>Home</Link>
          <Link to="/firmware" className={`text-lg ${location.pathname === '/firmware' ? 'active-menu' : ''}`}>Firmware Versions</Link>
          <Link to="/safety" className={`text-lg ${location.pathname === '/safety' ? 'active-menu' : ''}`}>Safety Measures</Link>
        </nav>
      </header>
      <Routes>
        <Route path="/" element={<CybersecurityInfo />} />
        <Route path="/firmware" element={<FirmwareVersions />} />
        <Route path="/safety" element={<SafetyMeasures />} />
      </Routes>
    </div>
  );
};

export default App;