import React from 'react';
import { Bar, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement);

const DeviceChart = ({ device }) =>
{
  // Dummy data for the charts
  const generateRandomData = (numDays) => {
    const data = [];
    for (let i = 0; i < numDays; i++) {
      data.push(Math.floor(Math.random() * 20)); // Random data between 0 and 20
    }
    return data;
  };

  const barData = {
    labels: Array.from({ length: 7 }, (_, i) => `Day ${i + 1}`), // Last 7 days
    datasets: [
      {
        label: 'Daily Updates',
        data: generateRandomData(7),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
    ],
  };

  const pieData = {
    labels: ['Updated', 'Pending', 'Not Updated'],
    datasets: [
      {
        data: [Math.floor(Math.random() * 15), Math.floor(Math.random() * 10), Math.floor(Math.random() * 5)],
        backgroundColor: ['#36A2EB', '#FFCE56', '#FF6384'],
      },
    ],
  };

  return (
    <div className="mt-4">
      <h3 className="text-xl font-semibold">{device.name} - Chart</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gray-700 p-4 rounded-lg">
          <h4 className="text-lg">Bar Chart</h4>
          <Bar data={barData} />
        </div>
        <div className="bg-gray-700 p-4 rounded-lg">
          <h4 className="text-lg">Pie Chart</h4>
          <Pie data={pieData} />
        </div>
      </div>
    </div>
  );
};

export default DeviceChart;
