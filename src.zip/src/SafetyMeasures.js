import React from 'react';

const SafetyMeasures = () => {
  return (
    <div className="p-4 bg-gray-800 text-white rounded-lg">
      <h2 className="text-2xl font-bold">Safety Measures</h2>
      <p>Information about safety measures and protocols in place.</p>
    </div>
  );
};

export default SafetyMeasures;
